package domain;

public class Admin extends Actor{

}
