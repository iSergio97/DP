package services;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import domain.Shout;

import repositories.ShoutRepository;
import security.LoginService;
import security.UserAccount;

@Service
@Transactional
public class ShoutService {

	// Instance fields --------------------------------------------------------

	@Autowired
	private ShoutRepository shoutRepository;

	// Instance methods -------------------------------------------------------

	public Collection<Shout> findAll() {
		Collection<Shout> result;

		result = shoutRepository.findAll();

		return result;
	}

	public Shout create() {
		Shout result;
		UserAccount userAccount;
		String username;

		userAccount = LoginService.getPrincipal();
		username = userAccount.getUsername();
		result = new Shout();

		result.setUsername(username);
		result.setLink("");
		result.setText("");

		return result;
	}

	public void save(Shout shout) {
		this.shoutRepository.save(shout);
	}

	public Map<String, Double> computeStatistics() {
		Map<String, Double> result;
		
		result = new HashMap<String, Double>();

		result.put("countAllShouts", (double) this.shoutRepository.countAllShouts());
		result.put("countShortShouts", (double) this.shoutRepository.countShortShouts());
		result.put("countLongShouts", (double) this.shoutRepository.countLongShouts());

		return result;
	}

}
