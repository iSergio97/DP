
package domain;

import java.util.Collection;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Access(AccessType.PROPERTY)
public class WorkPlan extends DomainEntity {

	// Relationships ----------------------------------------------------------

	private FixUpTask			fixUpTask;
	private Collection<Phase>	phases;


	// Relationship access methods --------------------------------------------

	@NotNull
	@Valid
	@OneToOne(optional = false, mappedBy = "workPlan")
	public FixUpTask getFixUpTask() {
		return this.fixUpTask;
	}

	public void setFixUpTask(final FixUpTask fixUpTask) {
		this.fixUpTask = fixUpTask;
	}

	@NotNull
	@Valid
	@NotEmpty
	@OneToMany(mappedBy = "workPlan", cascade = CascadeType.ALL)
	public Collection<Phase> getPhases() {
		return this.phases;
	}

	public void setPhases(final Collection<Phase> phases) {
		this.phases = phases;
	}

}
